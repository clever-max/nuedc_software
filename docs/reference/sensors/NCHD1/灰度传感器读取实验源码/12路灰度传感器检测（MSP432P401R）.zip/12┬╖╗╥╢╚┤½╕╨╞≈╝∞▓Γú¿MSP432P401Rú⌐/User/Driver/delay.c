#include <stdint.h>
#include <stdbool.h>
#include "Headfile.h"
#include "delay.h"

volatile uint32_t sysTickUptime = 0;

void delay(uint32_t ms) {
  uint32_t t0=millis();
	while(millis() - t0 < ms);
}
uint32_t micros(void)
{
    register uint32_t ms, cycle_cnt;
    do {
        ms = sysTickUptime;
        cycle_cnt = SysTick->VAL;
    } while (ms != sysTickUptime);
    return (ms * 1000) + (48 * 1000 - cycle_cnt) / 48;
}

void delayMicroseconds(uint32_t us) {
  uint32_t start = micros();
  while ((int32_t)(micros() - start) < us) {
    // Do nothing
  };
}

uint32_t millis(void) {
  return sysTickUptime;
}

void Delay_Ms(uint32_t x)
{
  delay(x);
}

void delay_ms(uint32_t x)
{
  Delay_Ms(x);
}


void delay_us(uint32_t x)
{
  delayMicroseconds(x);
}


void Delay_Us(uint32_t x) 
{
  delayMicroseconds(x);
}

void SysTick_Handler(void)
{
  sysTickUptime++;
}

/* Copyright (c)  2018-2025 Wuhan Nameless Innovation Technology Co.,Ltd. All rights reserved.*/

