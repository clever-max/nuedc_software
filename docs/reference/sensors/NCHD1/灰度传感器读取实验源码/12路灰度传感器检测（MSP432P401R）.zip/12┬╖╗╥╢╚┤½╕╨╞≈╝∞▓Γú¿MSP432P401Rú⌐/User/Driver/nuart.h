#ifndef __NUART__
#define __NUART__


void USART0_Send_Byte(uint8_t ch);
void USART0_Send_Bytes(uint8_t *pui8Buffer, uint32_t ui32Count);

void USART0_Init(void);


#endif

