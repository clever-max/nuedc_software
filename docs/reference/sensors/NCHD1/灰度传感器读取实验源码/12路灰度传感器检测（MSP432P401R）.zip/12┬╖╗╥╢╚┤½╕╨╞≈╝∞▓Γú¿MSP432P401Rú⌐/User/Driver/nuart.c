#include "Headfile.h"
#include "nuart.h"


//�����ʼ��㹫ʽ��
// N=ʱ����Ƶ/������
// ��� N<16  UCBRx=INT(N),UCBRF=0;
// ��� N>16  UCBRx=INT(N/16),UCBRF=INT{[(N/16)-INT(N/16)]*16}
// UCBRS ȡֵ��MSP432 USER'S GUIDE P731
// ���� ʹ�ü����� 
// software-dl.ti.com/msp430/msp430_public_sw/mcu/msp430/MSP430BaudRateConverter/index.html
//USCI/EUSCI:	EUSCI
//Clock 12M Hz	
/*
//UARTA2 Ring Buffer Global Variables
#define UARTA2_BUFFERSIZE 2048
volatile uint8_t UARTA2Data[UARTA2_BUFFERSIZE];
volatile uint32_t UARTA2ReadIndex;
volatile uint32_t UARTA2WriteIndex;
#define UARTA2_ADVANCE_READ_INDEX          MAP_Interrupt_disableMaster(); UARTA2ReadIndex = (UARTA2ReadIndex + 1) % UARTA2_BUFFERSIZE; MAP_Interrupt_enableMaster();
#define UARTA2_ADVANCE_WRITE_INDEX         UARTA2WriteIndex = (UARTA2WriteIndex + 1) % UARTA2_BUFFERSIZE
#define UARTA2_BUFFER_EMPTY                UARTA2ReadIndex == UARTA2WriteIndex ? true : false
#define UARTA2_BUFFER_FULL                 (UARTA2WriteIndex + 1) % UARTA2_BUFFERSIZE == UARTA2ReadIndex ? true : false
*/
eUSCI_UART_Config _uart_config;

typedef enum 
{
	BAUD_9600=0,
  BAUD_19200,
	BAUD_38400,
	BAUD_57600,
	BAUD_115200,
	BAUD_921600,
	BAUD_1382400,
  BAUD_NUM
}BAUD_DEF;



eUSCI_UART_Config namelesstech_msp432_buad_generate(uint8_t baud)
{
	eUSCI_UART_Config uart_config;
	switch(baud)
	{
		case BAUD_9600:
		{
			uart_config.selectClockSource=EUSCI_A_UART_CLOCKSOURCE_SMCLK;						//ѡ��ʱ��Դ
			uart_config.clockPrescalar=78;																					//ʱ��Ԥ��Ƶ��
			uart_config.firstModReg=2;   																						//ģʽ���üĴ���1
			uart_config.secondModReg=0;  																						//ģʽ���üĴ���2
			uart_config.parity=EUSCI_A_UART_NO_PARITY;        											//��żУ��
			uart_config.msborLsbFirst=EUSCI_A_UART_LSB_FIRST; 											//��ʼλ
			uart_config.numberofStopBits=EUSCI_A_UART_ONE_STOP_BIT;									//ֹͣλ
			uart_config.uartMode=EUSCI_A_UART_MODE;																	//����ģʽ
			uart_config.overSampling=EUSCI_A_UART_OVERSAMPLING_BAUDRATE_GENERATION;	//������	
		}break;
		case BAUD_19200:
		{
			uart_config.selectClockSource=EUSCI_A_UART_CLOCKSOURCE_SMCLK;						//ѡ��ʱ��Դ
			uart_config.clockPrescalar=39;																					//ʱ��Ԥ��Ƶ��
			uart_config.firstModReg=1;   																						//ģʽ���üĴ���1
			uart_config.secondModReg=0;  																						//ģʽ���üĴ���2
			uart_config.parity=EUSCI_A_UART_NO_PARITY;        											//��żУ��
			uart_config.msborLsbFirst=EUSCI_A_UART_LSB_FIRST; 											//��ʼλ
			uart_config.numberofStopBits=EUSCI_A_UART_ONE_STOP_BIT;									//ֹͣλ
			uart_config.uartMode=EUSCI_A_UART_MODE;																	//����ģʽ
			uart_config.overSampling=EUSCI_A_UART_OVERSAMPLING_BAUDRATE_GENERATION;	//������	
		}break;	
		case BAUD_38400:
		{
			uart_config.selectClockSource=EUSCI_A_UART_CLOCKSOURCE_SMCLK;						//ѡ��ʱ��Դ
			uart_config.clockPrescalar=19;																					//ʱ��Ԥ��Ƶ��
			uart_config.firstModReg=8;   																						//ģʽ���üĴ���1
			uart_config.secondModReg=85;  																					//ģʽ���üĴ���2
			uart_config.parity=EUSCI_A_UART_NO_PARITY;        											//��żУ��
			uart_config.msborLsbFirst=EUSCI_A_UART_LSB_FIRST; 											//��ʼλ
			uart_config.numberofStopBits=EUSCI_A_UART_ONE_STOP_BIT;									//ֹͣλ
			uart_config.uartMode=EUSCI_A_UART_MODE;																	//����ģʽ
			uart_config.overSampling=EUSCI_A_UART_OVERSAMPLING_BAUDRATE_GENERATION;	//������	
		}break;	
		case BAUD_57600:
		{
			uart_config.selectClockSource=EUSCI_A_UART_CLOCKSOURCE_SMCLK;						//ѡ��ʱ��Դ
			uart_config.clockPrescalar=13;																					//ʱ��Ԥ��Ƶ��
			uart_config.firstModReg=0;   																						//ģʽ���üĴ���1
			uart_config.secondModReg=37;  																					//ģʽ���üĴ���2
			uart_config.parity=EUSCI_A_UART_NO_PARITY;        											//��żУ��
			uart_config.msborLsbFirst=EUSCI_A_UART_LSB_FIRST; 											//��ʼλ
			uart_config.numberofStopBits=EUSCI_A_UART_ONE_STOP_BIT;									//ֹͣλ
			uart_config.uartMode=EUSCI_A_UART_MODE;																	//����ģʽ
			uart_config.overSampling=EUSCI_A_UART_OVERSAMPLING_BAUDRATE_GENERATION;	//������	
		}break;	
		case BAUD_115200:
		{
			uart_config.selectClockSource=EUSCI_A_UART_CLOCKSOURCE_SMCLK;						//ѡ��ʱ��Դ
			uart_config.clockPrescalar=6;																					  //ʱ��Ԥ��Ƶ��
			uart_config.firstModReg=8;   																						//ģʽ���üĴ���1
			uart_config.secondModReg=32;  																					//ģʽ���üĴ���2
			uart_config.parity=EUSCI_A_UART_NO_PARITY;        											//��żУ��
			uart_config.msborLsbFirst=EUSCI_A_UART_LSB_FIRST; 											//��ʼλ
			uart_config.numberofStopBits=EUSCI_A_UART_ONE_STOP_BIT;									//ֹͣλ
			uart_config.uartMode=EUSCI_A_UART_MODE;																	//����ģʽ
			uart_config.overSampling=EUSCI_A_UART_OVERSAMPLING_BAUDRATE_GENERATION;//������	
		}break;	
		case BAUD_921600:
		{
			uart_config.selectClockSource=EUSCI_A_UART_CLOCKSOURCE_SMCLK;						//ѡ��ʱ��Դ
			uart_config.clockPrescalar=13;																					//ʱ��Ԥ��Ƶ��
			uart_config.firstModReg=0;   																						//ģʽ���üĴ���1
			uart_config.secondModReg=0 ;  																					//ģʽ���üĴ���2
			uart_config.parity=EUSCI_A_UART_NO_PARITY;        											//��żУ��
			uart_config.msborLsbFirst=EUSCI_A_UART_LSB_FIRST; 											//��ʼλ
			uart_config.numberofStopBits=EUSCI_A_UART_ONE_STOP_BIT;									//ֹͣλ
			uart_config.uartMode=EUSCI_A_UART_MODE;																	//����ģʽ
			uart_config.overSampling=EUSCI_A_UART_LOW_FREQUENCY_BAUDRATE_GENERATION;//������	
		}break;
		case BAUD_1382400:
		{
			uart_config.selectClockSource=EUSCI_A_UART_CLOCKSOURCE_SMCLK;						//ѡ��ʱ��Դ
			uart_config.clockPrescalar=8;																					  //ʱ��Ԥ��Ƶ��
			uart_config.firstModReg=0;   																						//ģʽ���üĴ���1
			uart_config.secondModReg=214;  																					//ģʽ���üĴ���2
			uart_config.parity=EUSCI_A_UART_NO_PARITY;        											//��żУ��
			uart_config.msborLsbFirst=EUSCI_A_UART_LSB_FIRST; 											//��ʼλ
			uart_config.numberofStopBits=EUSCI_A_UART_ONE_STOP_BIT;									//ֹͣλ
			uart_config.uartMode=EUSCI_A_UART_MODE;																	//����ģʽ
			uart_config.overSampling=EUSCI_A_UART_LOW_FREQUENCY_BAUDRATE_GENERATION;//������	
		}break;	
		default:
		{
			uart_config.selectClockSource=EUSCI_A_UART_CLOCKSOURCE_SMCLK;						//ѡ��ʱ��Դ
			uart_config.clockPrescalar=6;																					  //ʱ��Ԥ��Ƶ��
			uart_config.firstModReg=8;   																						//ģʽ���üĴ���1
			uart_config.secondModReg=32;  																					//ģʽ���üĴ���2
			uart_config.parity=EUSCI_A_UART_NO_PARITY;        											//��żУ��
			uart_config.msborLsbFirst=EUSCI_A_UART_LSB_FIRST; 											//��ʼλ
			uart_config.numberofStopBits=EUSCI_A_UART_ONE_STOP_BIT;									//ֹͣλ
			uart_config.uartMode=EUSCI_A_UART_MODE;																	//����ģʽ
			uart_config.overSampling=EUSCI_A_UART_LOW_FREQUENCY_BAUDRATE_GENERATION;//������	
		}
	}
	return uart_config;
}



void EUSCIA0_IRQHandler(void)
{
	uint32_t status = MAP_UART_getEnabledInterruptStatus(EUSCI_A0_BASE);

	if(status & EUSCI_A_UART_RECEIVE_INTERRUPT_FLAG)
	{
		uint8_t ch=MAP_UART_receiveData(EUSCI_A0_BASE);
	}
	MAP_UART_clearInterruptFlag(EUSCI_A0_BASE, status);
}

void USART0_Send_Byte(uint8_t ch)
{
	MAP_UART_transmitData(EUSCI_A0_BASE, ch);
}

void USART0_Send_Bytes(uint8_t *pui8Buffer, uint32_t ui32Count)
{
  while(ui32Count--)
	{
		MAP_UART_transmitData(EUSCI_A0_BASE, *pui8Buffer);
		pui8Buffer++;
	}
}

void USART0_Init(void)
{
	_uart_config=namelesstech_msp432_buad_generate(BAUD_115200);
  MAP_GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P1,
             GPIO_PIN2 | GPIO_PIN3, GPIO_PRIMARY_MODULE_FUNCTION);
	/* Configuring UART Module */
	MAP_UART_initModule(EUSCI_A0_BASE, &_uart_config);

	/* Enable UART module */
	MAP_UART_enableModule(EUSCI_A0_BASE);
	//MAP_UART_clearInterruptFlag (EUSCI_A2_BASE);
	/* Enabling interrupts */
	MAP_UART_enableInterrupt(EUSCI_A0_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT);  
	MAP_Interrupt_enableInterrupt(INT_EUSCIA0);
}


int fputc(int ch, FILE *f){MAP_UART_transmitData(EUSCI_A0_BASE,ch);	return (ch);}
int fgetc(FILE *f) {int ch=MAP_UART_receiveData(EUSCI_A0_BASE);	return (ch);}

